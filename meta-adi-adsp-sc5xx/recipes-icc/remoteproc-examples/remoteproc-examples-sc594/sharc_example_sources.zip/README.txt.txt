To generate the *ldr files which are used by Linux, compile this project and then take the resulting 2 files:

LED_Blink_SC594_SHARC_Core1.dxe and LED_Blink_SC594_SHARC_Core2.dxe

On these two files, perform this operation:

elfloader -proc ADSP-SC594 -si-revision 0.0 -core2=LED_Blink_SC594_SHARC_Core1.dxe -b SPI -f BINARY -Width 8 -bcode 0x1 -verbose -o LED_Blink_SC594_SHARC_Core1.ldr

and

elfloader -proc ADSP-SC594 -si-revision 0.0 -core2=LED_Blink_SC594_SHARC_Core2.dxe -b SPI -f BINARY -Width 8 -bcode 0x1 -verbose -o LED_Blink_SC594_SHARC_Core2.ldr

This will produce

LED_Blink_SC594_SHARC_Core1.ldr and LED_Blink_SC594_SHARC_Core2.ldr, which can then by loaded through remoteproc by renaming them to:

adi_adsp_core1_fw.ldr and adi_adsp_core2_fw.ldr



The same goes from the mcapi examples:

Core 1:
elfloader -proc ADSP-SC594 -si-revision 0.0 -core1=mcapi_send_recv_Core1_sc594.dxe -b SPI -f BINARY -Width 8 -bcode 0x1 -verbose -o mcapi_send_recv_Core1_sc594.ldr

Core 2:
elfloader -proc ADSP-SC594 -si-revision 0.0 -core2=mcapi_send_recv_Core2_sc594.dxe -b SPI -f BINARY -Width 8 -bcode 0x1 -verbose -o mcapi_send_recv_Core2_sc594.ldr