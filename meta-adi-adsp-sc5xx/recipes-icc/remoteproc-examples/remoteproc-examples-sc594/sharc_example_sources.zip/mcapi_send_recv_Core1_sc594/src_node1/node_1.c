/*****************************************************************************
 * Example: MCAPI_msg
 * Project: MCAPI_msg_Node1
 * File:    node_1.c
 *
 * Copyright(c) 2013-2020 Analog Devices, Inc. All Rights Reserved.
 * This software is proprietary and confidential.  By using this software you
 * agree to the terms of the associated Analog Devices License Agreement.
 *****************************************************************************/

#include <stdio.h>
#include <assert.h>
#include <services/mcapi/mcapi.h>
#include <sys/adi_core.h>

#include "../MCAPI_msg.h"
#include "node_1.h"

/* Commands are received via local command end-point */
static mcapi_endpoint_t dsp_recv_endpoint;
static mcapi_endpoint_t arm_recv_endpoint;

/* Create endpoints and connection for DSP
 * returns bool, true for success, false for failure
 */
bool dsp_initialize(mcapi_node_t remoteNode, mcapi_port_t port) {
	mcapi_status_t status;

	/**
	 * Create end-point for data and command transfer.
	 */
	dsp_recv_endpoint = mcapi_endpoint_create(port, &status);
	if (MCAPI_SUCCESS != status) {
		fprintf(ERR_STREAM, "[%s] %d status: %d mcapi_endpoint_create failure\n",
				__FILE__, __LINE__, status);
		return false;
	}

	arm_recv_endpoint = mcapi_endpoint_get(0, 0, 101, MCAPI_TIMEOUT_INFINITE, &status);


	return true;
}

/* closes the ports and shuts down the DSP
 * returns bool, true for success, false for failure
 */
bool dsp_shutdown(void) {

	mcapi_status_t mcapi_status = MCAPI_ERR_GENERAL;

	/* Delete the local end-point */
	mcapi_endpoint_delete(dsp_recv_endpoint, &mcapi_status);
	if (MCAPI_SUCCESS != mcapi_status) {
		fprintf(ERR_STREAM, "[%s] %d status: %d mcapi_endpoint_delete failure\n",
				__FILE__, __LINE__, mcapi_status);
		return false;
	}

	/* Shutdown MCAPI */
	mcapi_finalize(&mcapi_status);
	if (MCAPI_SUCCESS != mcapi_status) {
		fprintf(ERR_STREAM, "[%s] %d status: %d mcapi_finalize failure\n",
				__FILE__, __LINE__, mcapi_status);
		return false;
	}

	return true;
}

/* DSP command loop
 * returns bool, true for success, false for failure
 */
bool dsp_command_loop(bool (*pfProcess_data)(struct DSP_MSG *)) {

	mcapi_status_t status;
	size_t msg_size = 0;
	struct DSP_MSG msg;
	struct DSP_MSG vBuffer;
	int core = adi_core_id();
	int digit = 0;
	int fromCore = 0;

	for (int i = 0; i < 100; i++) {

		memset(msg, 0, sizeof(struct DSP_MSG));
		memset(vBuffer, 0, sizeof(struct DSP_MSG));

		/* Wait for a message */
		mcapi_msg_recv(dsp_recv_endpoint, &msg, sizeof(struct DSP_MSG),
				&msg_size, &status);

		if (MCAPI_SUCCESS != status && MCAPI_PENDING != status) {
			fprintf(ERR_STREAM, "[%s] %d status: %d mcapi_msg_recv failure\n", __FILE__,
					__LINE__, status);
			return false;
		}else{
			msg.buffer[msg.buffSize] = '\0';
			sscanf(msg.buffer, "hello core %d message from core 0 - %d\0", &fromCore, &digit);
			vBuffer.buffSize = 64;
			snprintf(vBuffer.buffer, vBuffer.buffSize, "hello core 0 message from core %d - %d\0", fromCore, ++digit);
			vBuffer.buffSize = strlen(vBuffer.buffer);

			/* Send a message back */
			mcapi_msg_send(dsp_recv_endpoint, arm_recv_endpoint, &vBuffer, sizeof(struct DSP_MSG), 0, &status);
			if (MCAPI_SUCCESS != status) {
				fprintf(ERR_STREAM, "[%s] %d status: %d mcapi_msg_send failure\n", __FILE__,
						__LINE__, status);
				return false;
			}
		}

	}

	return true;
}
