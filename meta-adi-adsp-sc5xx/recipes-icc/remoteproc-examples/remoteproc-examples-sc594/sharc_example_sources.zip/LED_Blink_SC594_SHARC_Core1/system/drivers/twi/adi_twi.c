/*
 *****************************************************************************
 * @file:    adi_twi.c
 * @brief:   TWI Device Driver for Blackfin & SHARC processors
 * @version: $Revision: 65202 $
 * @date:    $Date: 2020-10-28 12:43:35 -0400 (Wed, 28 Oct 2020) $
 *****************************************************************************

 Copyright(c) 2011-2020 Analog Devices, Inc. All Rights Reserved.

 This software is proprietary and confidential.  By using this software you agree
 to the terms of the associated Analog Devices License Agreement.

 *********************************************************************************/
/*!
 * @file      adi_twi.c
 *
 * @brief     TWI device driver global file.
 *
 * @details
 *            This a global file which includes a specific file based on the processor family.
 *            This included file will be  containing  TWI device  driver functions.
 */


/* disable misra diagnostics as necessary */
#ifdef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress:misra_rule_5_1:"Identifiers shall not rely on the significance of more than 31 characters")
#pragma diag(suppress:misra_rule_8_5:"There shall be no definitions of objects or functions in a header file")
#endif /* _MISRA_RULES */

#include <sys/platform.h>

#if defined(__ADSP21569_FAMILY__) || defined(__ADSPSC594_FAMILY__)
#include "adi_twi_2156x.c"
#elif defined(__ADSPSC589_FAMILY__) || defined(__ADSPSC573_FAMILY__)
#if defined(SSLDD_3_TWI_SUPPORT_FOR_SC5xx)
#include "adi_twi_2156x.c"
#else
#include "adi_twi_v1.c"
#endif
#else
#include "adi_twi_v1.c"
#endif


#ifdef _MISRA_RULES
#pragma diag(pop)
#endif /* _MISRA_RULES */

/*@}*/
