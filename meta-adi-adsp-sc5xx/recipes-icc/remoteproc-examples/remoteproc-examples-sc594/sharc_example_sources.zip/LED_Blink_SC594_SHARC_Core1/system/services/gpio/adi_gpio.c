/*********************************************************************************

Copyright(c) 2011-2020 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.

*********************************************************************************/
/*!
* @file      adi_gpio.c
* @brief     This is the primary source file for the GPIO Driver.
* @version:  $Revision: 64700 $
* @date:     $Date: 2020-08-21 10:07:34 -0400 (Fri, 21 Aug 2020) $
*
*            Contains the implementation of the APIs for the  general-purpose
*            input/output (GPIO) port driver.
*
*/

/* disable MISRA diagnostics as necessary */
#ifdef _MISRA_RULES
#pragma diag(push)
#pragma diag(suppress:misra_rule_2_4:"(advisory) Sections of code should not be commented out.")
#pragma diag(suppress:misra_rule_5_6:"(advisory) No identifier in one name space should have the same spelling as an identifier in another name space.")
#pragma diag(suppress:misra_rule_5_1:"Allow identifiers to be longer than 31 characters.")
#pragma diag(suppress:misra_rule_5_7:"(advisory) No identifier name should be reused.")
#pragma diag(suppress:misra_rule_8_5:"There shall be no definitions of objects or functions in a header file")
#pragma diag(suppress:misra_rule_11_4:"(advisory) A cast should not be performed between a pointer to object type and a different pointer to object type.")
#pragma diag(suppress:misra_rule_13_7:"Boolean operations whose results are invariant shall not be permitted.")
#pragma diag(suppress:misra_rule_14_7:"A function shall have a single point of exit at the end of the function.")
#pragma diag(suppress:misra_rule_17_4:"Array indexing shall be the only allowed form of pointer arithmetic.")
#pragma diag(suppress:misra_rule_19_15:"Precautions shall be taken in order to prevent the contents of a header file being included twice.")
#endif /* _MISRA_RULES */

/** @addtogroup GPIO_Service GPIO Service
 *  @{
 *
      General-Purpose Input/Output (GPIO)

Each GPIO-capable pin shares functionality with other processor
peripherals via a multiplexing scheme; however, the GPIO
functionality is the default state of the device upon power-up.
Neither GPIO output nor input drivers are active by default.
Each general-purpose port pin can be individually controlled by
manipulation of the port control, status, and interrupt registers:
- GPIO direction control register; Specifies the direction of
each individual GPIO pin as input or output.

- GPIO control and status registers; The processor employs
a 'write one to modify' mechanism that allows any combination
of individual GPIO pins to be modified in a single
instruction, without affecting the level of any other GPIO
pins. Control registers are provided. One register is
written in order to set pin values, one register is written in
order to clear pin values, one register is written in order to
toggle pin values, and one register is written in order to
specify a pin value. Reading the GPIO status register allows
software to interrogate the sense of the pins.

- GPIO interrupt mask registers; The GPIO interrupt
mask registers allow each individual GPIO pin to function
as an interrupt to the processor. Similar to the GPIO
control registers that are used to set and clear individual
pin values, one GPIO interrupt mask register sets bits to
enable interrupt function, and the other GPIO interrupt
mask register clears bits to disable interrupt function.
GPIO pins defined as inputs can be configured to generate
hardware interrupts, while output pins can be triggered by
software interrupts.

- GPIO interrupt sensitivity registers; The GPIO interrupt
sensitivity registers specify whether individual pins are
level or edge-sensitive and specify if edge-sensitive
whether just the rising edge or both the rising and falling
edges of the signal are significant. One register selects the
type of sensitivity, and one register selects which edges are
significant for edge-sensitivity.

API applicability by processor type:

           - API's common to all processors:
                  - adi_gpio_Init()
                  - adi_gpio_SetDirection()
                  - adi_gpio_Set()
                  - adi_gpio_Clear()
                  - adi_gpio_Toggle()
                  - adi_gpio_GetData()
                  - adi_gpio_RegisterCallback()
                  - adi_gpio_UnRegisterCallback()

           - API's used on processors without Pin Interrupt Registers:
                  - adi_gpio_SetInputEdgeSense()
                  - adi_gpio_EnableInterruptMask()

           - Additional API's used on processors with Pin Interrupt Registers:
                  - adi_gpio_PinInterruptAssignment()
                  - adi_gpio_EnablePinInterruptMask()
                  - adi_gpio_SetPinIntEdgeSense()
                  - adi_gpio_GetPinInterruptState()

           - Additional API's used on processors with port hysteresis registers:
                  - adi_gpio_EnableInputHysteresis()

           - Additional API's used on the BF60x, BF7xx, SC58x and SC57x processors:
                  - adi_gpio_EnablePolar()
                  - adi_gpio_EnableLock()
                  - adi_gpio_GetRevision()



GPIO macro usage:

            To control a single GPIO, macros can be passed to the functions one
            at a time. For example, to set the GPIO on port F, pin 4 to a logical high
            level, the following is used:

                 adi_gpio_Set(ADI_GPIO_PORT_F, ADI_GPIO_PIN_4);

            Multiple GPIOs, so long as they reside on the same port, can be controlled
            simultaneously. Macros can be OR-ed together and passed to the
            functions. For example, to set the GPIOs on port F, pins 3, 4 and 7 to
            a logical low level, the following is used:

                 adi_gpio_Clear(ADI_GPIO_PORT_F, ADI_GPIO_PIN_3 | ADI_GPIO_PIN_4 | ADI_GPIO_PIN_7);

            For the sensing, the return value is a packed value containing the status
            of all the GPIOs on the given port. To test the level of a specific GPIO,
            simply perform a logical AND of the return value with the GPIO pin definition.
            For example to see if pin 4 on port F is set, the following is used:

            adi_gpio_GetData(ADI_GPIO_PORT_F, &data)
            if (data & ADI_GPIO_PIN_4)
               pin 4 on port F is set
            else
               pin 4 on port F is clear
 *
 */

#include <services/gpio/adi_gpio.h>
#include <services/int/adi_int.h>
#include <adi_osal.h>
#include <stddef.h>
#include <assert.h>

#define ADI_GPIO_CHANNEL_UNDEFINED (-1)
#define ADI_GPIO_PORT_UNDEFINED    (-1)
#define ADI_GPIO_PIN_INT_UNDEFINED (-1)

/*
 * Processors with a pin interrupt module
 */
#if defined(__ADSPBF548_FAMILY__) || defined(__ADSPBF548M_FAMILY__) || \
    defined(__ADSPBF609_FAMILY__) || \
    defined(ADI_ADSP_CM40Z)       || \
    defined(ADI_ADSP_CM41X)       || \
    defined(__ADSPBF707_FAMILY__) || \
    defined(__ADSPBF725W_FAMILY__) || \
    defined(__ADSPSC589_FAMILY__) || \
    defined(__ADSPSC573_FAMILY__) || \
	defined(__ADSP21569_FAMILY__) || \
	defined(__ADSPSC594_FAMILY__)

#include "adi_gpio_pint.c"

#else

#include "adi_gpio_no_pint.c"

#endif

#if defined(__ADSP21569_FAMILY__) || defined(__ADSPSC594_FAMILY__)
#include "adi_gpio_pads.c"
#endif

/* alias for the actual device structure */
typedef ADI_GPIO_PORT_INFO ADI_GPIO_DRIVER;

#ifdef ADI_DEBUG
bool ValidatePort(ADI_GPIO_PORT port)
{
	bool bResult = true;

	if((uint8_t)(port) >= (uint8_t)NUM_GPIO_PORTS)
	{
		bResult = false;
	}

	return bResult;
}
#endif

/*
 * API's
 */

/**
 * @brief Initialize GPIO callback memory space.
 *
 * Memory space is needed when using GPIO callbacks.  The application must
 * allocate memory space for GPIO use.  The amount of memory needed depends
 * on the number of callbacks to be registered.
 *
 * @param [in]  pDeviceMemory    Pointer to the allocated memory space.
 * @param [in]  nMemorySize      The size of the memory space (bytes).
 * @param [out] pMaxCallbacks    The number of callbacks that can be registered given this amount of memory.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS           Successfully initialized GPIO.
 *             - #ADI_GPIO_INVALID_MEMORY    The memory pointer or size is invalid.
 *
 * @sa adi_gpio_RegisterCallback
 *
 */
ADI_GPIO_RESULT adi_gpio_Init(
		void *const             pDeviceMemory,
		uint32_t                nMemorySize,
		uint32_t				*pMaxCallbacks)
{
    ADI_GPIO_CALLBACK_ENTRY *pEntry;
    uint32_t index;
    /* Pointer for keeping track of application supplied memory usage */
    uint8_t *pAvailableMem = (uint8_t *) pDeviceMemory;

#if defined(ADI_DEBUG)
    if ((pDeviceMemory == (void*)0) || (nMemorySize == 0u)) {
    	return ADI_GPIO_INVALID_MEMORY;
    }

    /* Asserts to validate the memory size macros */
    assert(ADI_GPIO_CALLBACK_MEM_SIZE == sizeof(ADI_GPIO_CALLBACK_ENTRY));

#endif

    /* initialize the callback structure */
	callbackInfo.pCallbackData = (ADI_GPIO_CALLBACK_ENTRY*)pAvailableMem;
	callbackInfo.MaxCallbacks = nMemorySize/(sizeof(ADI_GPIO_CALLBACK_ENTRY));

	/* initialize the memory */
	pEntry = callbackInfo.pCallbackData;
	for (index = 0u; index < callbackInfo.MaxCallbacks; index++) {
#if defined(__ADI_GPIO_HAS_PINT__)
		pEntry->ePinInt = (ADI_GPIO_PIN_INTERRUPT)ADI_GPIO_PIN_INT_UNDEFINED;
#else
		pEntry->ePort = (ADI_GPIO_PORT)ADI_GPIO_PORT_UNDEFINED;
#endif
		pEntry->Pins = 0u;
   		pEntry->pfCallback = (ADI_GPIO_CALLBACK)0;
   		pEntry->pCBParam = (void*)0;
   		pEntry++;
	}

	*pMaxCallbacks = callbackInfo.MaxCallbacks;

	return ADI_GPIO_SUCCESS;
}

/**
 * @brief Set the GPIO direction.
 *
 * Sets the given GPIO pin(s) to an input or output direction.
 *
 * @param [in] ePort       The GPIO port.
 * @param [in] Pins        The pin(s) to set as input or output.
 * @param [in] eDirection  The direction to set.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS               Successfully set the GPIO direction.
 *             - #ADI_GPIO_INVALID_PORT [D]      The port parameter is invalid.
 *             - #ADI_GPIO_INVALID_DIRECTION [D] The direction parameter is invalid.
 * 
 */
ADI_GPIO_RESULT adi_gpio_SetDirection(
    ADI_GPIO_PORT       const ePort,
    uint32_t            const Pins,
    ADI_GPIO_DIRECTION  const eDirection)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

#ifdef ADI_DEBUG
    /* validate direction */
    if((eDirection != ADI_GPIO_DIRECTION_INPUT) && (eDirection != ADI_GPIO_DIRECTION_OUTPUT))
    {
        return ADI_GPIO_INVALID_DIRECTION;
    }

    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif /* ADI_DEBUG */

	adi_osal_EnterCriticalRegion();

#if defined(__ADI_GPIO_HAS_PINT__)
	if (eDirection == ADI_GPIO_DIRECTION_INPUT)
	{
		/* write PORTx_DIR_CLEAR to clear appropriate bits for input direction */
		*(port->DirClear) = (REGSIZE)Pins; /* write 1 to clear */
		/* write PORTx_INEN to set appropriate bits to enable input drivers direction */
		*(port->InputEnable) |= (REGSIZE)Pins;
	} else {
		/* output */
		/* write PORTx_DIR_SET TO SET appropriate bits for output direction */
		*(port->DirSet) = (REGSIZE)Pins; /* write 1 to set */
		/* write PORTx_INEN to clear appropriate bits to disable input drivers direction */
		*(port->InputEnable) &= (REGSIZE)~(REGSIZE)Pins;
	}
#else
	if (eDirection == ADI_GPIO_DIRECTION_INPUT)
	{
		/* write PORTxIO_DIR to clear appropriate bits for input direction */
		*(port->Direction) &= (REGSIZE)~(REGSIZE)Pins;
		/* write PORTxIO_INEN to set appropriate bits to enable input drivers direction */
		*(port->InputEnable) |= (REGSIZE)Pins;
	} else {
		/* output */
		/* write PORTxIO_DIR TO SET appropriate bits for output direction */
		*(port->Direction) |= (REGSIZE)Pins;
		/* write PORTxIO_INEN to clear appropriate bits to disable input drivers direction */
		*(port->InputEnable) &= (REGSIZE)~(REGSIZE)Pins;
	}
#endif

	adi_osal_ExitCriticalRegion();

	return ADI_GPIO_SUCCESS;
}


/**
 * @brief Sets the given GPIO pin(s) to a logic high level.  The logic level
 * of other pins is not changed.
 *
 *
 * @param [in] ePort       The GPIO port.
 * @param [in] Pins        The pin(s) to set to a logic high level.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully set the GPIO logic level.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 * @sa adi_gpio_Clear
 * @sa adi_gpio_Toggle
 *
 */
ADI_GPIO_RESULT adi_gpio_Set(
    ADI_GPIO_PORT       const ePort,
    uint32_t            const Pins)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

#ifdef ADI_DEBUG
    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif

	/* write PORTxIO_SET to set appropriate bits to raise individual gpio */
	*(port->Set) = (REGSIZE)Pins; /* Write-1-to-set */

	return ADI_GPIO_SUCCESS;
}

/**
 * @brief Sets the given GPIO pin(s) to a logic low level.  The logic level
 * of other pins is not changed.
 *
 * @param [in] ePort       The GPIO port.
 * @param [in] Pins        The pin(s) to set to a logic low level.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully set the GPIO logic level.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 * @sa adi_gpio_Set
 * @sa adi_gpio_Toggle
 *
 */
ADI_GPIO_RESULT adi_gpio_Clear(
    ADI_GPIO_PORT       const ePort,
    uint32_t            const Pins)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

#ifdef ADI_DEBUG
    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif

	/* write PORTxIO_CLEAR to set appropriate bits to lower individual gpio */
	*(port->Clear) = (REGSIZE)Pins; /* Write-1-to-clear */

	return ADI_GPIO_SUCCESS;
}

/**
 * @brief Toggle the logic level of the given GPIO pin(s).  The logic level
 * of other pins is not changed.
 *
 * @param [in] ePort       The GPIO port.
 * @param [in] Pins        The pin(s) to set to toggle.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully set the GPIO logic level.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 * @sa adi_gpio_Set
 * @sa adi_gpio_Clear
 *
 */
ADI_GPIO_RESULT adi_gpio_Toggle(
    ADI_GPIO_PORT       const ePort,
    uint32_t            const Pins)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

#ifdef ADI_DEBUG
    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif

#if defined(__ADSPBF548_FAMILY__) || defined(__ADSPBF548M_FAMILY__)
	adi_osal_EnterCriticalRegion();

	/*  use exclusive or to toggle individual gpio */
	*(port->Data) ^= (REGSIZE)Pins;

	adi_osal_ExitCriticalRegion();
#else
	/* write PORTxIO_TOGGLE to set appropriate bits to toggle individual gpio */
	*(port->Toggle) = (REGSIZE)Pins; /* Write-1-to-toggle */
#endif

    return ADI_GPIO_SUCCESS;
}

#if defined(__ADSP21569_FAMILY__) || defined(__ADSPSC594_FAMILY__)
/**
 * @brief Toggle the state of the given GPIO pin(s)in response to a trigger from TRU.
 *
 * EnableWhen global toggling the state of output GPIO pins in response to a trigger from TRU
 * for the corresponding port. Setting bits in the PORT_TRIG_TGL register enables triggers to
 * toggle the state of those specific pins without impacting other pins of the port.
 *
 * @param [in]  ePort       The GPIO port to lock/unlock.
 *
 * @param [in] Pins        The pin(s) to set/clear to polar inversion.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully locked/unlocked the GPIO port.
 *
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 *
 */

ADI_GPIO_RESULT adi_gpio_TriggerToggle(ADI_GPIO_PORT  const ePort,
											uint32_t   const Pins)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

	ADI_GPIO_RESULT eResult = ADI_GPIO_SUCCESS;

#ifdef ADI_DEBUG
	    if (!ValidatePort(ePort))
	    {
	    	eResult = ADI_GPIO_INVALID_PORT;
	    }
#endif
	    /* write PORT_TRIG_TGL to set appropriate bits to toggle individual gpio on trigger response*/
	    *(port->TriggerToggle) = (REGSIZE)Pins;  /* Write-1-to-trigger toggle */

	    return eResult;
}

/**
 * @brief One step end-to-end configuration for given GPIO Port pins as Input or Output pin.
 *  Configuring a Port Pin as input or output can also be done by calling the individual APIs
 *  such as adi_gpio_SetDirection() and adi_gpio_Set()/adi_gpio_Clear(). This API is intended to
 *  provide the functionality of two of the above APIs into one. This is restricted only for GPIO
 *  Pins and does not include configuration for Peripheral muxing
 *
 * @param [in]  ePort     Select the GPIO Port to be configured.
 *
 * @param [in]  Pins      The pin(s) to be configured.
 *
 * @param [in]  eDirection	  Select the GPIO direction to be configured i.e. Input or Output
 * 						  By default, in input mode, the Pin Polarity is not inverted
 * 						  To invert the Pin polarity, use the adi_gpio_EnablePolar API
 *
 * @param [in]  bEnable	  To set(true) or clear(false) the data pins in GPIO output mode
 * 						  To set(true) or clear(false) the PORT_INEN to enable input drivers.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS                   Successfully got the GPIO pin data.
 *
 *             - #ADI_GPIO_INVALID_PORT 			 GP Port selected is invalid.
 *
 *             - #ADI_GPIO_INVALID_DIRECTION		 The GP Pins direction selected is invalid
 *
 *
 */

ADI_GPIO_RESULT adi_gpio_PortInit(ADI_GPIO_PORT const ePort,
								uint32_t  const Pins,
								ADI_GPIO_DIRECTION const eDirection,
								bool bEnable)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

	ADI_GPIO_RESULT eResult = ADI_GPIO_SUCCESS;

#ifdef ADI_DEBUG
	if (!ValidatePort(ePort))
	{
		eResult = ADI_GPIO_INVALID_PORT;
	}
#endif

	 *(port->Fer) &= ~((REGSIZE) Pins);

	if(eDirection == ADI_GPIO_DIRECTION_INPUT)
	{
		*(port->Clear) = (REGSIZE) Pins;

		if(bEnable)
		{
			*(port->InputEnable) = (REGSIZE) Pins;
		}
		else
		{
			*(port->InputEnable) &= ~(REGSIZE) Pins;
		}

		*(port->DirClear)= (REGSIZE)Pins;
	}
	else if(eDirection == ADI_GPIO_DIRECTION_OUTPUT)
	{
		if(bEnable)
		{
			*(port->Set) = (REGSIZE) Pins;
		}
		else
		{
			*(port->Clear) = (REGSIZE) Pins;
		}

		*(port->DirSet)= (uint32_t)Pins;
	}
	else
	{
		eResult =  ADI_GPIO_INVALID_DIRECTION;
	}

	return eResult;

}


#endif
/**
 * @brief Get the logic level of the given GPIO Pins(s) on the given port
 *
 * The return value is a packed value containing the status of all the GPIOs
 * on the given port. To test the level of a specific GPIO, simply perform a
 * logical AND of the return value with the GPIO pin definition. For example
 * to see if pin 4 on port F is set, the following is used:
 *
 * adi_GPIO_GetData(ADI_GPIO_PORT_F, &data)
 * if (data & ADI_GPIO_PIN_4)
 *    pin 4 on port F is set
 * else
 *    pin 4 on port F is clear
 *
 * @param [in]  ePort       The GPIO port.
 * @param [out] pValue      The value of the port GPIO pins.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully got the GPIO pin data.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 * @sa adi_gpio_Set
 * @sa adi_gpio_Clear
 * @sa adi_gpio_Toggle
 *
 */
ADI_GPIO_RESULT adi_gpio_GetData(
    ADI_GPIO_PORT       const ePort,
    uint32_t                 *pValue)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

#ifdef ADI_DEBUG
    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif

    /* get the PORTxIO data */
    *pValue = *(port->Data);

	return ADI_GPIO_SUCCESS;
}

#if defined(__ADSPBF609_FAMILY__) || defined(ADI_ADSP_CM40Z) || defined(ADI_ADSP_CM41X) || \
    defined(__ADSPBF707_FAMILY__) || defined(__ADSPBF725W_FAMILY__) || defined(__ADSPSC589_FAMILY__) || defined(__ADSPSC573_FAMILY__) ||\
	defined(__ADSP21569_FAMILY__) || defined(__ADSPSC594_FAMILY__)
/**
 * @brief Enable or disable polar inversion on the given GPIO Pins(s) on the given port.
 *
 * @note Only available on processors with a port polar register.
 *
 * PORTx_POLAR/PORTx_POLAR_SET/PORTx_POLAR_CLEAR registers are used for programming
 * inversion on GPIO signals only. Peripheral signals have the inversion selection
 * programming in their corresponding module/block.
 *
 * @param [in] ePort       The GPIO port.
 * @param [in] Pins        The pin(s) to set/clear to polar inversion.
 * @param [in] bEnable     True to set polar inversion on the given pins,
 *                         false to clear polar inversion.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully got the GPIO pin data.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 *
 * @sa adi_gpio_Set
 * @sa adi_gpio_Clear
 * @sa adi_gpio_Toggle
 *
 */
ADI_GPIO_RESULT adi_gpio_EnablePolar(
    ADI_GPIO_PORT       const ePort,
    uint32_t            const Pins,
    bool                const bEnable)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

#ifdef ADI_DEBUG
    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif

    if (bEnable)
    {
    	/* write PORTx_POL_SET to enable polarity */
    	*(port->PolarSet) = (REGSIZE)Pins; /* Write-1-to-set */
    }
    else
    {
    	/* write PORTx_POL_CLEAR to disable polarity */
    	*(port->PolarClear) = (REGSIZE)Pins; /* Write-1-to-clear */
    }

	return ADI_GPIO_SUCCESS;
}

/**
 * @brief Enable or disable port lock controls.
 *
 * @note Only available on processors with a port lock register.
 *
 * Enable/Disable write access to the corresponding GPIO registers. When global
 * lock is enabled and lock bit is set, if a write is attempted to a write
 * protected register an error will be generated.
 *
 * @param [in]  ePort       The GPIO port to lock/unlock.
 * @param [in]  Lock        One or more ADI_GPIO_LOCK defines OR'ed together.
 * @param [in]  bEnable     True to lock the desired port registers, false to unlock.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully locked/unlocked the GPIO port.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 *
 */
ADI_GPIO_RESULT adi_gpio_EnableLock(
    ADI_GPIO_PORT       const ePort,
    uint32_t            const Lock,
    bool                const bEnable)
{
	ADI_GPIO_PORT_INFO *port = &PortInfo[ePort];

#ifdef ADI_DEBUG
    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif

	adi_osal_EnterCriticalRegion();

	if (bEnable)
	{
		*(port->Lock) |= Lock;
	}
	else
	{
		*(port->Lock) &= (uint32_t)~Lock;
	}

	adi_osal_ExitCriticalRegion();

	return ADI_GPIO_SUCCESS;
}

/**
 * @brief Get the module version.
 *
 * @note Only available on processors with a REVID register.
 *
 * Get the revision number from the PORTx_REVID read only register.
 *
 * @param [in]  ePort       The GPIO port to read the module version number.
 * @param [out] pValue      The module version number.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully read the module version number.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *             - #ADI_GPIO_NOT_SUPPORTED    The REVID register is not available.
 *
 *
 */
ADI_GPIO_RESULT adi_gpio_GetRevision(
    ADI_GPIO_PORT       const ePort,
    uint32_t                 *pValue)
{
#ifdef ADI_DEBUG
    if (!ValidatePort(ePort))
    {
    	return ADI_GPIO_INVALID_PORT;
    }
#endif

    /* currently this API is not supported on any processor */
	return ADI_GPIO_NOT_SUPPORTED;
}
#endif

#if defined(__ADSPBF609_FAMILY__)
/**
 * @brief Configures hysteresis for the PORT inputs.
 *
 * @note Only available on processors with a HYST register.
 *
 * Configures hysteresis (HYST) for the PORTx inputs. The hysteresis enable
 * can be set only for pin groups, classified by the PORTx (consisting of 16 GPIO pins
 * each).  By default hysteresis is enabled on all GPIO pins.
 *
 * @param [in]  Ports       The GPIO ports to enable/disable hysteresis.
 *                          One or more #ADI_GPIO_PADS_PORT enumerations OR'ed together.
 * @param [in]  bEnable     True to enable hysteresis, false to disable.
 *
 * @return
 *             - #ADI_GPIO_SUCCESS          Successfully enables/disabled hysteresis.
 *             - #ADI_GPIO_INVALID_PORT [D] The port parameter is invalid.
 *
 */
ADI_GPIO_RESULT adi_gpio_EnableInputHysteresis(
    uint32_t            const Ports,
    bool                const bEnable)
{
	adi_osal_EnterCriticalRegion();

	if (bEnable)
	{
		*pREG_PADS0_PORTS_HYST |= Ports;
	}
	else
	{
		*pREG_PADS0_PORTS_HYST &= (uint32_t)~Ports;
	}

	adi_osal_ExitCriticalRegion();

	return ADI_GPIO_SUCCESS;
}
#endif

/*@}*/

#ifdef _MISRA_RULES
#pragma diag(pop)
#endif /* _MISRA_RULES */

