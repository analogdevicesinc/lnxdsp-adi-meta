/*******************************************************************************

Copyright(c) 2020 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you
agree to the terms of the associated Analog Devices License Agreement.

*******************************************************************************/
 
/*****************************************************************************
 * LED_Blink.c
 *****************************************************************************/

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"

#include "LED_Blink.h"

void SoftSwitches_EV_21593_SOM_LED_ON(void);
void SoftSwitches_EV_21593_SOM_LED_OFF(void);

/** 
 * If you want to use command program arguments, then place them in the following string. 
 */
char __argv_string[] = "";

int main(int argc, char *argv[])
{
	/**
	 * Initialize managed drivers and/or services that have been added to 
	 * the project.
	 * @return zero on success 
	 */
	adi_initComponents();

	volatile int i=0;
	while(1)
	{
		/* Turn LED on */
		SoftSwitches_EV_21593_SOM_LED_ON();

		/*Delay*/
		for(i=0;i<0x1000000;i++);

		/* Turn LED off */
		SoftSwitches_EV_21593_SOM_LED_OFF();

		/*Delay*/
		for(i=0;i<0x1000000;i++);

	}

}

