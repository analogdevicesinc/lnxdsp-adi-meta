/*******************************************************************************

Copyright(c) 2020 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you
agree to the terms of the associated Analog Devices License Agreement.

*******************************************************************************/
 
/*****************************************************************************
 * LED_Blink.c
 *****************************************************************************/

#include <sys/platform.h>
#include <sys/adi_core.h>
#include "adi_initialize.h"

#include "LED_Blink_SC594_SHARC_Core2.h"

void SoftSwitches_EV_21593_SOM_LED_ON(void);
void SoftSwitches_EV_21593_SOM_LED_OFF(void);

/** 
 * If you want to use command program arguments, then place them in the following string. 
 */
char __argv_string[] = "";

int main(int argc, char *argv[])
{
	/**
	 * Initialize managed drivers and/or services that have been added to 
	 * the project.
	 * @return zero on success 
	 */
	adi_initComponents();

	ADI_GPIO_RESULT Result;

	/*Configure the Port Pin PC_01 as output for LED blink*/
	Result = adi_gpio_SetDirection(ADI_GPIO_PORT_C,ADI_GPIO_PIN_1, ADI_GPIO_DIRECTION_OUTPUT);
	if(Result!= ADI_GPIO_SUCCESS)
	{
		printf("GPIO Initialization failed \n");
	}

	/*Configure the Port Pin PC_02 as output for LED blink*/
	Result = adi_gpio_SetDirection(ADI_GPIO_PORT_C,ADI_GPIO_PIN_2, ADI_GPIO_DIRECTION_OUTPUT);
	if(Result!= ADI_GPIO_SUCCESS)
	{
		printf("GPIO Initialization failed \n");
	}

	/*Configure the Port Pin PC_03 as output for LED blink*/
	Result = adi_gpio_SetDirection(ADI_GPIO_PORT_C,ADI_GPIO_PIN_3, ADI_GPIO_DIRECTION_OUTPUT);
	if(Result!= ADI_GPIO_SUCCESS)
	{
		printf("GPIO Initialization failed \n");
	}

	volatile int i=0;
	while(1)
	{
		/* Turn LED on */
		adi_gpio_Toggle(ADI_GPIO_PORT_C,ADI_GPIO_PIN_1);
		adi_gpio_Toggle(ADI_GPIO_PORT_C,ADI_GPIO_PIN_2);
		adi_gpio_Toggle(ADI_GPIO_PORT_C,ADI_GPIO_PIN_3);

		/*Delay*/
		for(i=0;i<0x1000000;i++);

		/* Turn LED off */
		adi_gpio_Toggle(ADI_GPIO_PORT_C,ADI_GPIO_PIN_1);
		adi_gpio_Toggle(ADI_GPIO_PORT_C,ADI_GPIO_PIN_2);
		adi_gpio_Toggle(ADI_GPIO_PORT_C,ADI_GPIO_PIN_3);

		/*Delay*/
		for(i=0;i<0x1000000;i++);

	}

}

