/*********************************************************************************
Copyright(c) 2020 Analog Devices, Inc. All Rights Reserved.
This software is proprietary and confidential. By using this software you agree
to the terms of the associated Analog Devices License Agreement.
 *********************************************************************************/
 
/*****************************************************************************
 * LED_Blink_SC594_SHARC_Core2.h
 *****************************************************************************/

#ifndef __LED_BLINK_SC594_SHARC_CORE2_H__
#define __LED_BLINK_SC594_SHARC_CORE2_H__

/* Add your custom header content here */
#include <services/gpio/adi_gpio.h>
#include <stdio.h>

#endif /* __LED_BLINK_SC594_SHARC_CORE2_H__ */
