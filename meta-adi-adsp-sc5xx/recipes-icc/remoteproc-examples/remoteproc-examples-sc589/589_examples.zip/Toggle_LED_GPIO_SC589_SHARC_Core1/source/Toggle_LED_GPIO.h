/*********************************************************************************

Copyright(c) 2014-2015 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.

*********************************************************************************/

/*!
* @file     Button_LED_GPIO.h
*
* @brief    Primary header file for GPIO service example.
*
* @details  Primary header file for GPIO which contains the processor specific defines.
*
*/


#ifndef _BUTTON_LED_GPIO_H_
#define _BUTTON_LED_GPIO_H_

#if defined(__ADSPSC589__)
/*
 * LED 1 GPIO settings
 */

/* GPIO port to which LED 1 is connected to */
#define LED1_PORT                   (ADI_GPIO_PORT_E)

/* GPIO pin within the port to which LED 1 is connected to */
#define LED1_PIN                    (ADI_GPIO_PIN_13)


/*
 * LED 2 GPIO settings
 */

/* GPIO port to which LED 2 is connected to */
#define LED2_PORT                   (ADI_GPIO_PORT_E)

/* GPIO pin within the port to which LED 2 is connected to */
#define LED2_PIN                    (ADI_GPIO_PIN_14)

#elif defined(__ADSPSC584__)
/*
 * LED 1 GPIO settings
 */

/* GPIO port to which LED 1 is connected to */
#define LED1_PORT                   (ADI_GPIO_PORT_E)

/* GPIO pin within the port to which LED 1 is connected to */
#define LED1_PIN                    (ADI_GPIO_PIN_1)


/*
 * LED 2 GPIO settings
 */

/* GPIO port to which LED 2 is connected to */
#define LED2_PORT                   (ADI_GPIO_PORT_E)

/* GPIO pin within the port to which LED 2 is connected to */
#define LED2_PIN                    (ADI_GPIO_PIN_2)


#elif defined(__ADSPSC573__)
/*
 * LED 1 GPIO settings
 */

/* GPIO port to which LED 1 is connected to */
#define LED1_PORT                   ADI_GPIO_PORT_E

/* GPIO pin within the port to which LED 1 is connected to */
#define LED1_PIN                    ADI_GPIO_PIN_13

/*
 * LED 2 GPIO settings
 */

/* GPIO port to which LED 2 is connected to */
#define LED2_PORT                   ADI_GPIO_PORT_A

/* GPIO pin within the port to which LED 2 is connected to */
#define LED2_PIN                    ADI_GPIO_PIN_9
#endif

#endif /* _BUTTON_LED_GPIO_H_ */
