/*********************************************************************************

Copyright(c) 2015 Analog Devices, Inc. All Rights Reserved.

This software is proprietary and confidential.  By using this software you agree
to the terms of the associated Analog Devices License Agreement.

*********************************************************************************/

#include <services/gpio/adi_gpio.h>
#include "Toggle_LED_GPIO.h"

static void delay(const uint32_t iSpeed)
{
    uint32_t x, y;
    uint32_t counter = 500000u;

    for( x = 0u; x < iSpeed; x++ )
    {
        for( y = 0u; y < counter; y++ )
        {
            NOP();
        }
    }
}

int main(void)
{
    /* set GPIO output LED 1 */
    adi_gpio_SetDirection(
        LED2_PORT,
        LED2_PIN,
        ADI_GPIO_DIRECTION_OUTPUT);

    while(1){
    	adi_gpio_Set(LED2_PORT, LED2_PIN);
    	delay(100);
    	adi_gpio_Clear(LED2_PORT, LED2_PIN);
    	delay(100);
    }
}


